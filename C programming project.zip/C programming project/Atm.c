#include <stdio.h>
 
unsigned long amount=1200, deposit, withdraw_amount;
int choice, oldpin, L;
int newpin;
char transaction ='y';
 
void main()
{
	while (oldpin != 1234)
	{
		printf("ENTER YOUR SECRET PIN NUMBER:");
		scanf("%d", &oldpin);
		if (oldpin != 1234)
		printf("PLEASE ENTER VALID PASSWORD\n");
	}
	do
	{
        printf("******Created by Uttam kumar ********\n");
		printf("***Welcome to ATM Service*****\n");
		printf("1. Check Balance\n");
		printf("2. Withdraw Cash\n");
		printf("3. Deposit Cash\n");
		printf("4. Pin change\n");
		printf("5. Quit\n");
		printf("******?*********?\n\n");
		printf("Enter your choice: ");
		scanf("%d", &choice);
		switch (choice)
		{
		case 1:
			printf("\n YOUR BALANCE IN Rs : %lu ", amount);
			break;
		case 2:
			printf("\n ENTER THE AMOUNT TO WITHDRAW: ");
			scanf("%lu", &withdraw_amount);
            
                
			if (withdraw_amount % 100 != 0)
			{
				printf("\n PLEASE ENTER THE AMOUNT IN MULTIPLES OF 100");
			}
			else if (withdraw_amount >(amount - 500))
			{
				printf("\n INSUFFICENT BALANCE");
			}
			else
			{
				amount = amount - withdraw_amount;
				printf("\n\n PLEASE COLLECT CASH");
				printf("\n YOUR CURRENT BALANCE IS :- %lu", amount);
			}
			break;
		case 3:
			printf("\n ENTER THE AMOUNT TO DEPOSIT :- ");
			scanf("%lu", &deposit);
                        amount = amount + deposit;
			printf("YOUR BALANCE IS :-  %lu", amount);
			break;
		case 4:
            printf("Enter your new pin:-");
			scanf("%d",&newpin);
			oldpin = newpin;
			printf("Your pin has been sucessfully changed");
			break;
		case 5:
			printf("\n THANK U FOR USING ATM");
			break;
		default:
			printf("\n INVALID CHOICE");
		}
		printf("\n\n DO U WISH TO HAVE ANOTHER TRANSCATION?(y/n): \n");
		fflush(stdin);
		scanf("%c", &transaction);
		if (transaction == 'n'|| transaction == 'N')
                    L = 1;
	} while (!L);
	printf("\n\n THANKS FOR USING OUR ATM SERVICE");
}